import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { Page } from "@/components/site/Nav";
import { Reveal } from "@/components/site/Reveal";
import { AssetPlaceholder, StatusTag } from "@/components/site/Work";
import { caseStudies } from "@/content/site";

export const Route = createFileRoute("/work/$slug")({
  loader: ({ params }) => {
    const i = caseStudies.findIndex((p) => p.slug === params.slug);
    if (i < 0) throw notFound();
    return { p: caseStudies[i]!, next: caseStudies[(i + 1) % caseStudies.length]! };
  },
  head: ({ loaderData }) => {
    const t = loaderData ? `${loaderData.p.title} — Riley Hammond` : "Project — Riley Hammond";
    const d = loaderData?.p.summary ?? "Case study by Riley Hammond.";
    return {
      meta: [
        { title: t }, { name: "description", content: d },
        { property: "og:title", content: t }, { property: "og:description", content: d },
        { property: "og:type", content: "article" }, { name: "twitter:card", content: "summary_large_image" },
      ],
    };
  },
  notFoundComponent: () => (
    <Page><div className="mx-auto max-w-7xl px-6 py-32 md:px-10"><h1 className="font-display text-6xl">Project not found</h1><Link to="/work" className="eyebrow link-underline mt-8 inline-block pb-1">← All work</Link></div></Page>
  ),
  component: CaseStudyPage,
});

function Row({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <Reveal className="grid gap-4 border-t py-8 md:grid-cols-[1fr_2fr] md:gap-12">
      <h2 className="eyebrow text-rose">{label}</h2>
      <div className="text-lg leading-relaxed text-charcoal">{children}</div>
    </Reveal>
  );
}

function CaseStudyPage() {
  const { p, next } = Route.useLoaderData();
  const isCampaign = p.slug === "butterfield-farm-market";
  return (
    <Page>
      <article className="mx-auto max-w-7xl px-6 py-16 md:px-10">
        <Link to="/work" className="eyebrow link-underline pb-1">← All work</Link>
        <div className="mt-12 flex flex-wrap items-center gap-3">
          <span className="eyebrow text-rose">{p.type}</span>
          <StatusTag s={p.status} />
        </div>
        <h1 className="font-display animate-rise mt-4 max-w-5xl text-5xl md:text-7xl lg:text-8xl">{p.title}</h1>
        <p className="mt-6 max-w-2xl text-xl text-charcoal">{p.summary}</p>
        <dl className="mt-10 grid gap-6 border-y py-6 sm:grid-cols-3">
          {p.facts.map((f) => <div key={f.k}><dt className="eyebrow text-muted-foreground">{f.k}</dt><dd className="mt-1">{f.v}</dd></div>)}
        </dl>

        <AssetPlaceholder label={`${p.title} — hero image`} className="mt-12 aspect-[16/8]" />

        <div className="mt-16">
          <Row label="Context & problem">{p.problem}</Row>
          <Row label="Goals & audience">{p.goals}</Row>
          <Row label="My role">
            <p>{p.role}</p>
            <ul className="mt-4 space-y-2">{p.contributions.map((c) => <li key={c}>— {c}</li>)}</ul>
          </Row>
          <Row label="Tools">{p.tools.join(" · ")}</Row>
        </div>

        <h2 className="font-display mt-24 text-4xl md:text-6xl">{p.chapterLabel}</h2>

        {p.apps ? (
          <div className="mt-12 grid gap-10 md:grid-cols-2">
            {p.apps.map((a) => (
              <Reveal key={a.title} className="border-t pt-6">
                <AssetPlaceholder label={`${a.title} — screenshots or prototype`} className="aspect-[4/3]" />
                <h3 className="font-display mt-6 text-3xl">{a.title}</h3>
                <dl className="mt-4 space-y-3 text-charcoal">
                  <div><dt className="eyebrow text-muted-foreground">Assignment</dt><dd>{a.assignment}</dd></div>
                  <div><dt className="eyebrow text-muted-foreground">Description</dt><dd>{a.description}</dd></div>
                  <div><dt className="eyebrow text-muted-foreground">Technologies</dt><dd>{a.tech.join(" · ")}</dd></div>
                  <div><dt className="eyebrow text-muted-foreground">What I learned</dt><dd>{a.learned}</dd></div>
                </dl>
              </Reveal>
            ))}
          </div>
        ) : (
          <ol className={`mt-12 grid gap-x-6 gap-y-12 ${isCampaign ? "md:grid-cols-3" : "md:grid-cols-2"}`}>
            {p.chapters.map((c, i) => (
              <Reveal key={c.title} className={!isCampaign && (c.assets?.length ?? 0) > 1 ? "md:col-span-2" : ""}>
                <li className="list-none border-t pt-5">
                  <div className="flex flex-wrap items-center justify-between gap-3">
                    <span className="eyebrow text-rose">{String(i + 1).padStart(2, "0")}</span>
                    {c.status && <StatusTag s={c.status} />}
                  </div>
                  <h3 className="font-display mt-3 text-2xl md:text-3xl">{c.title}</h3>
                  {c.body && <p className="mt-3 text-charcoal">{c.body}</p>}
                  {c.assets && (
                    <div className={`mt-5 grid gap-4 ${c.assets.length > 1 ? "sm:grid-cols-2 lg:grid-cols-3" : ""}`}>
                      {c.assets.map((a) => <AssetPlaceholder key={a} label={a} />)}
                    </div>
                  )}
                </li>
              </Reveal>
            ))}
          </ol>
        )}

        <div className="mt-20"><Row label="Outcome & next steps">{p.reflection}</Row></div>

        <div className="mt-16 flex flex-col gap-10 border-t pt-10 md:flex-row md:items-end md:justify-between">
          <Link to="/work/$slug" params={{ slug: next.slug }} className="group block">
            <span className="eyebrow text-muted-foreground">Next project</span>
            <span className="font-display mt-3 block text-4xl transition-transform group-hover:translate-x-2 md:text-6xl">{next.title} →</span>
          </Link>
          <Link to="/work" className="eyebrow link-underline pb-1">All work</Link>
        </div>
      </article>
    </Page>
  );
}
